<!DOCTYPE html>
<html>
<head>	
	<title>Ujian TW 2</title>
	<script src="ckeditor/ckeditor.js"></script>

</head>
<body>
	
		<textarea class="ckeditor" name="editor"></textarea>

</body>
</html>