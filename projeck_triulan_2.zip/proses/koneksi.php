<?php
$connect = mysqli_connect("localhost", "root", "", "projeck_triulan_2");
?>	